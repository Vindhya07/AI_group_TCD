from setuptools import setup

setup(name='gym_tetris',
      version='1',
      install_requires=['gym', 'numpy', 'pygame', 'tensorflow==2.0.0-rc0', 'tensorflow-gpu==2.0.0-rc0', 'tensorboard']
      )
